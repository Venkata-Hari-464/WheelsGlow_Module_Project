package com.example.wheelsglow;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.razorpay.Checkout;
import com.razorpay.PaymentResultListener;

import org.json.JSONObject;

public class show_room_service extends AppCompatActivity implements PaymentResultListener {
    String cat, service, amount;
    TextView category, service_pay, amount_pay;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_room_service);
        Intent intent = getIntent();
        cat = intent.getStringExtra("category");
        service = intent.getStringExtra("service");
        amount = intent.getStringExtra("amount");
        category = findViewById(R.id.fetch_pay_category);
        service_pay = findViewById(R.id.fetch_pay_service);
        amount_pay = findViewById(R.id.get_amount);
        category.setText(cat);
        service_pay.setText(service);
        amount_pay.setText(amount);
        Checkout.preload(show_room_service.this);
    }

    public void startPayment(View view) {
        if (amount != null) {
            // Initialize Razorpay checkout
            Checkout checkout = new Checkout();
            checkout.setKeyID("rzp_test_zogp4w4jLlCNCx");

            try {
                // Extract numeric part of amount and convert to paise
                String numericAmount = amount.replaceAll("\\D+", ""); // Extract numeric part (449)
                int amountInPaise = Integer.parseInt(numericAmount) * 100; // Convert to paise
                // Create a JSON object with payment details
                JSONObject options = new JSONObject();
                options.put("name", cat);
                options.put("description", service);
                options.put("currency", "INR");
                options.put("amount", amountInPaise);

                JSONObject retryObj = new JSONObject();
                retryObj.put("enable",true);
                retryObj.put("maxcount",4);
                options.put("retry",retryObj);
                // Open Razorpay checkout activity
                checkout.open(show_room_service.this, options);
            } catch (Exception e) {
                // Handle exceptions
                Toast.makeText(this, "Error in payment: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                e.printStackTrace();
            }
        } else {
            Toast.makeText(this, "Error: Amount is null", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onPaymentSuccess(String razorpayPaymentID) {
        // Handle payment success
        Toast.makeText(this, "Payment Successful", Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(show_room_service.this,customer_home.class);
        startActivity(intent);
    }

    @Override
    public void onPaymentError(int code, String response) {
        // Handle payment failure
        Toast.makeText(this, "Payment Failed: " + response, Toast.LENGTH_SHORT).show();
        Log.e("paym", "payment_failed" + response);
    }
}
