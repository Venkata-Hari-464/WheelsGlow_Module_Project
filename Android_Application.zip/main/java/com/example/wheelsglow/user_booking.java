package com.example.wheelsglow;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class user_booking extends AppCompatActivity {
    private RecyclerView recyclerView;
    private List<bookingInfo> dataList;
    private CustomAdapter adapter;
    String user_id = "25";
    BottomNavigationView bottomNavigationView;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_booking);
        Intent intent=getIntent();
        user_id=intent.getStringExtra("user_id");
        recyclerView = findViewById(R.id.myBookings);

        dataList = new ArrayList<>();
        adapter = new CustomAdapter(dataList);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setBackgroundColor(getResources().getColor(android.R.color.white));
        recyclerView.setAdapter(adapter);
        bottomNavigationView = findViewById(R.id.bottom_navigation);
        bottomNavigationView.setOnNavigationItemReselectedListener(new BottomNavigationView.OnNavigationItemReselectedListener() {
            @Override
            public void onNavigationItemReselected(@NonNull MenuItem item) {
                int id = item.getItemId();
                if (id == R.id.navigation_home) {
                    Intent intent = new Intent(getApplicationContext(), customer_home.class);
                    startActivity(intent);
                }
                if (id == R.id.customer_bookings) {
                    Intent intent = new Intent(getApplicationContext(), user_booking.class);
                    intent.putExtra("user_id",user_id);
                    startActivity(intent);
                }
                if (id == R.id.customer_profile) {
                    Intent intent = new Intent(getApplicationContext(), user_booking_part.class);
                    intent.putExtra("user_id",user_id);
                    startActivity(intent);
                }
            }
        });
        new FetchCategoryDetailsTask().execute();
    }

    class CustomAdapter extends RecyclerView.Adapter<CustomAdapter.ViewHolder> {

        private List<bookingInfo> dataList;

        public CustomAdapter(List<bookingInfo> dataList) {
            this.dataList = dataList;
        }

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = getLayoutInflater().inflate(R.layout.custom_bookings, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
            bookingInfo booking = dataList.get(position);

            if (holder.nameTextView != null) {
                holder.nameTextView.setText(booking.getCompanyName() != null ? booking.getCompanyName() : "");
            }
            if (holder.modelTextView != null) {
                holder.modelTextView.setText(booking.getCarModel() != null ? booking.getCarModel() : "");
            }
            if (holder.dateTextView != null) {
                holder.dateTextView.setText(booking.getDate() != null ? booking.getDate() : "");
            }
            if (holder.statusTextView != null) {
                holder.statusTextView.setText(booking.getStatus() != null ? booking.getStatus() : "");
            }

            // Set OnClickListener for the itemView
            holder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // Handle item click, start next activity and pass data
                    Intent intent = new Intent(user_booking.this, user_booking_part.class);
                    // Pass data using intent extras
                    intent.putExtra("company", booking.getCompanyName());
                    intent.putExtra("carModel", booking.getCarModel());
                    intent.putExtra("date", booking.getDate());
                    intent.putExtra("status", booking.getStatus());
                    intent.putExtra("amount", booking.getAmount());
                    startActivity(intent);
                }
            });
        }

        @Override
        public int getItemCount() {
            return dataList.size();
        }

        public class ViewHolder extends RecyclerView.ViewHolder {
            TextView nameTextView, modelTextView, dateTextView, statusTextView;

            public ViewHolder(View itemView) {
                super(itemView);
                nameTextView = itemView.findViewById(R.id.company_Booking);
                modelTextView = itemView.findViewById(R.id.model_Booking);
                dateTextView = itemView.findViewById(R.id.date_booking);
                statusTextView = itemView.findViewById(R.id.status_booking);
            }
        }
    }

    private class FetchCategoryDetailsTask extends AsyncTask<Void, Void, String> {
        @Override
        protected String doInBackground(Void... voids) {
            try {
                URL url = new URL("http://10.0.2.2/wheels/fetch_userBookings.php");
                HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestMethod("POST");
                urlConnection.setDoOutput(true);
                String parameters = "user_id=" + user_id;
                urlConnection.getOutputStream().write(parameters.getBytes());
                InputStream inputStream = urlConnection.getInputStream();
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
                StringBuilder response = new StringBuilder();
                String line;

                while ((line = bufferedReader.readLine()) != null) {
                    response.append(line).append("\n");
                }

                bufferedReader.close();
                inputStream.close();
                urlConnection.disconnect();

                return response.toString();
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }

        @Override
        protected void onPostExecute(String result) {
            Log.e("Response", "Result from server: " + result);
            // Pass the response to handleCategoryDetailsResponse
            handleCategoryDetailsResponse(result);
        }
    }

    private void handleCategoryDetailsResponse(String response) {
        if (response != null) {
            try {
                JSONObject jsonResponse = new JSONObject(response);
                String status = jsonResponse.optString("status", "");

                if ("Success".equals(status)) {
                    JSONArray categoryDataArray = jsonResponse.optJSONArray("data");

                    if (categoryDataArray != null) {
                        for (int i = 0; i < categoryDataArray.length(); i++) {
                            JSONObject categoryData = categoryDataArray.optJSONObject(i);

                            if (categoryData == null) {
                                continue;
                            }

                            bookingInfo booking = new bookingInfo(
                                    categoryData.optString("companyname", ""),
                                    categoryData.optString("carmodel", ""),
                                    categoryData.optString("date", ""),
                                    categoryData.optString("status", ""),
                                    categoryData.optString("amount", "")
                            );
                            dataList.add(booking);
                        }

                        adapter.notifyDataSetChanged();
                    }
                } else if ("NoData".equals(status)) {
                    // Handle case when no category data is available
                    Log.e("Response", "No category data available");
                } else {
                    // Handle other error cases
                    Log.e("Response", "Error: " + status);
                }
            } catch (JSONException e) {
                e.printStackTrace();
                // Handle JSON parsing error
                Log.e("Response", "JSON parsing error");
            }
        } else {
            // Handle case when response is null
            Log.e("Response", "Response is null");
        }
    }

    static class bookingInfo {
        private String companyName;
        private String carModel;
        private String date;
        private String status;
        private String amount;

        public bookingInfo(String companyName, String carModel, String date, String status, String amount) {
            this.companyName = companyName;
            this.carModel = carModel;
            this.date = date;
            this.status = status;
            this.amount = amount;
        }

        public String getCompanyName() {
            return companyName;
        }

        public String getCarModel() {
            return carModel;
        }

        public String getDate() {
            return date;
        }

        public String getStatus() {
            return status;
        }

        public String getAmount() {
            return amount;
        }
    }
}
