package com.example.wheelsglow;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class customer_home extends AppCompatActivity {
    private RecyclerView recyclerView;
    private List<categoryInfo> dataList;
    private CustomAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customer_home);

        recyclerView = findViewById(R.id.customer_service_category);
        dataList = new ArrayList<>();
        adapter = new CustomAdapter(dataList);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setBackgroundColor(getResources().getColor(android.R.color.white));
        recyclerView.setAdapter(adapter);
        new FetchCategoryDetailsTask().execute();
    }

    class CustomAdapter extends RecyclerView.Adapter<CustomAdapter.ViewHolder> {

        private List<categoryInfo> dataList;


        public CustomAdapter(List<categoryInfo> dataList) {
            this.dataList = dataList;

        }

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = getLayoutInflater().inflate(R.layout.service_under_category, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
            categoryInfo category = dataList.get(position);

            if (holder.nameTextView != null) {
                holder.nameTextView.setText( (category.getName() != null ? category.getName() : ""));
            }
            if (holder.serviceTextView != null) {
                holder.serviceTextView.setText( (category.getInformation() != null ? category.getInformation() : ""));
            }


            if (holder.profileImageView != null && category.getImageUrl() != null && !category.getImageUrl().isEmpty()) {
                String completeImageUrl = "http://10.0.2.2/wheels/images/" + category.getImageUrl();
                Log.e("ImageUrl","Img url"+category.getImageUrl());
                Picasso.get().load(completeImageUrl).into(holder.profileImageView);
            } else {
                holder.profileImageView.setImageResource(R.drawable.ic_launcher_background);
            }
            holder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // Navigate to next activity and pass category name
                    Intent intent = new Intent(customer_home.this, service_offered.class);
                    intent.putExtra("category", category.getName());
                    startActivity(intent);
                }
            });
        }

        @Override
        public int getItemCount() {
            return dataList.size();
        }

        public class ViewHolder extends RecyclerView.ViewHolder {
            TextView nameTextView, serviceTextView;
            ImageView profileImageView;

            public ViewHolder(View itemView) {
                super(itemView);
                nameTextView = itemView.findViewById(R.id.categoryTitle);
                serviceTextView = itemView.findViewById(R.id.textDescription);

                profileImageView = itemView.findViewById(R.id.service_image);
            }
        }
    }

    private class FetchCategoryDetailsTask extends AsyncTask<Void, Void, String> {
        @Override
        protected String doInBackground(Void... voids) {
            try {
                URL url = new URL("http://10.0.2.2/wheels/fetch_category_customer.php");
                HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestMethod("POST");
                urlConnection.setDoOutput(true);

                InputStream inputStream = urlConnection.getInputStream();
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
                StringBuilder response = new StringBuilder();
                String line;

                while ((line = bufferedReader.readLine()) != null) {
                    response.append(line).append("\n");
                }

                bufferedReader.close();
                inputStream.close();
                urlConnection.disconnect();

                return response.toString();
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }

        @Override
        protected void onPostExecute(String result) {
            Log.e("ojo", "Result from server: " + result);

            handleCategoryDetailsResponse(result);
        }
    }

    private void handleCategoryDetailsResponse(String response) {
        if (response != null) {
            try {
                JSONObject jsonResponse = new JSONObject(response);
                String status = jsonResponse.optString("status", "");

                if ("Success".equals(status)) {
                    JSONArray categoryDataArray = jsonResponse.optJSONArray("data");

                    if (categoryDataArray != null) {
                        for (int i = 0; i < categoryDataArray.length(); i++) {
                            JSONObject categoryData = categoryDataArray.optJSONObject(i);

                            if (categoryData == null) {
                                continue;
                            }

                            categoryInfo category = new categoryInfo(
                                    categoryData.optString("servicename", ""),  // Corrected key to "servicename"
                                    categoryData.optString("informations", ""), // Corrected key to "informations"
                                    categoryData.optString("image", "")
                            );
                            dataList.add(category);
                        }

                        adapter.notifyDataSetChanged();
                    }
                } else if ("NoData".equals(status)) {
                    // Handle case when no category data is available
                    Log.e("ojo", "No category data available");
                } else {
                    // Handle other error cases
                    Log.e("ojo", "Error: " + status);
                }
            } catch (JSONException e) {
                e.printStackTrace();
                // Handle JSON parsing error
                Log.e("ojo", "JSON parsing error");
            }
        } else {
            // Handle case when response is null
            Log.e("ojo", "Response is null");
        }
    }


    class categoryInfo {
        private String name;
        private String information;
        private String imageUrl;


        public categoryInfo(String name, String information, String imageUrl) {
            this.name = name;
            this.information = information;
            this.imageUrl=imageUrl;

        }

        public String getName() {
            return name;
        }

        public String getInformation() {
            return information;
        }


        public String getImageUrl() {
            return imageUrl;
        }
    }
}
