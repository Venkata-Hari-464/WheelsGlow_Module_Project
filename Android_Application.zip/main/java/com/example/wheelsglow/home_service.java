package com.example.wheelsglow;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.app.TimePickerDialog;
import android.content.DialogInterface;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class home_service extends AppCompatActivity {
    Button book;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_service);
        book=findViewById(R.id.book_home_slot);
        book.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bookSlot(null);
            }
        });
    }

    public void selectDate(View view) {
        DatePickerDialog datePickerDialog = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                String date = dayOfMonth + "/" + (month + 1) + "/" + year;
                EditText preferredDateEditText = findViewById(R.id.preferred_date);
                preferredDateEditText.setText(date);
            }
        }, Calendar.getInstance().get(Calendar.YEAR), Calendar.getInstance().get(Calendar.MONTH), Calendar.getInstance().get(Calendar.DAY_OF_MONTH));
        datePickerDialog.show();
    }

    public void selectTime(View view) {
        int hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        int minute = Calendar.getInstance().get(Calendar.MINUTE);

        // Create a TimePickerDialog with 12-hour format
        TimePickerDialog timePickerDialog = new TimePickerDialog(this, new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                String amPm;
                if (hourOfDay < 12) {
                    amPm = "AM";
                    if (hourOfDay == 0) {
                        hourOfDay = 12;
                    }
                } else {
                    amPm = "PM";
                    if (hourOfDay != 12) {
                        hourOfDay -= 12;
                    }
                }
                String time = String.format(Locale.getDefault(), "%02d:%02d %s", hourOfDay, minute, amPm);
                EditText preferredTimeEditText = findViewById(R.id.preferred_time);
                preferredTimeEditText.setText(time);
            }
        }, hour, minute, false); // Use false for 12-hour format

        timePickerDialog.show();
    }

    public void bookSlot(View view) {
        EditText vehicleCompanyEditText = findViewById(R.id.vehicle_company);
        EditText vehicleModelEditText = findViewById(R.id.vehicle_model);
        EditText preferredDateEditText = findViewById(R.id.preferred_date);
        EditText preferredTimeEditText = findViewById(R.id.preferred_time);
        EditText address1EditText = findViewById(R.id.address1);
        EditText address2EditText = findViewById(R.id.address2);
        EditText pincodeEditText = findViewById(R.id.pincode);
        EditText landmarkEditText = findViewById(R.id.landmark);
        EditText contactNumberEditText = findViewById(R.id.contact_number);
        EditText alternativeContactNumberEditText = findViewById(R.id.alternative_contact_number);

        String vehicleCompany = vehicleCompanyEditText.getText().toString().trim();
        String vehicleModel = vehicleModelEditText.getText().toString().trim();
        String preferredDate = preferredDateEditText.getText().toString().trim();
        String preferredTime = preferredTimeEditText.getText().toString().trim();
        String address1 = address1EditText.getText().toString().trim();
        String address2 = address2EditText.getText().toString().trim();
        String pincode = pincodeEditText.getText().toString().trim();
        String landmark = landmarkEditText.getText().toString().trim();
        String contactNumber = contactNumberEditText.getText().toString().trim();
        String alternativeContactNumber = alternativeContactNumberEditText.getText().toString().trim();

        if (vehicleCompany.isEmpty() || vehicleModel.isEmpty() || preferredDate.isEmpty() ||
                preferredTime.isEmpty() || address1.isEmpty() || address2.isEmpty() ||
                pincode.isEmpty() || landmark.isEmpty() || contactNumber.isEmpty() ||
                alternativeContactNumber.isEmpty()) {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        Map<String, String> postData = new HashMap<>();
        postData.put("vehicle_company", vehicleCompany);
        postData.put("vehicle_model", vehicleModel);
        postData.put("preferred_date", preferredDate);
        postData.put("preferred_time", preferredTime);
        postData.put("address1", address1);
        postData.put("address2", address2);
        postData.put("pincode", pincode);
        postData.put("landmark", landmark);
        postData.put("contact_number", contactNumber);
        postData.put("alternative_contact_number", alternativeContactNumber);

        new SendDataToServer().execute(postData);
    }

    private class SendDataToServer extends AsyncTask<Map<String, String>, Void, String> {

        ProgressDialog progressDialog;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressDialog = new ProgressDialog(home_service.this);
            progressDialog.setMessage("Sending data...");
            progressDialog.setCancelable(false);
            progressDialog.show();
        }

        @Override
        protected String doInBackground(Map<String, String>... maps) {
            try {
                URL url = new URL("http://10.0.2.2/wheels/register_service.php");
                Toast.makeText(home_service.this, "connecting", Toast.LENGTH_SHORT).show();
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("POST");
                connection.setDoOutput(true);

                OutputStream outputStream = connection.getOutputStream();
                outputStream.write(getPostDataString(maps[0]).getBytes());
                outputStream.flush();
                outputStream.close();

                InputStream inputStream = connection.getInputStream();
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
                StringBuilder response = new StringBuilder();
                String line;
                while ((line = bufferedReader.readLine()) != null) {
                    response.append(line);
                }
                bufferedReader.close();
                inputStream.close();
                connection.disconnect();

                return response.toString();
            } catch (IOException e) {
                e.printStackTrace();
                return "Error: " + e.getMessage();
            }
        }

        @Override
        protected void onPostExecute(String result) {
            Log.e("resp0nse", "result" + result);
            super.onPostExecute(result);
            progressDialog.dismiss();

            AlertDialog.Builder builder = new AlertDialog.Builder(home_service.this);
            builder.setTitle("Server Response");
            try {
                JSONObject jsonObject = new JSONObject(result);
                String message = jsonObject.getString("message");
                builder.setMessage(message);
            } catch (JSONException e) {
                e.printStackTrace();
                builder.setMessage("Error: " + e.getMessage());
            }
            builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    // You can perform any action on OK button click
                }
            });
            builder.show();
        }
    }

    private static String getPostDataString(Map<String, String> postData) throws UnsupportedEncodingException {
        StringBuilder result = new StringBuilder();
        boolean first = true;
        for (Map.Entry<String, String> entry : postData.entrySet()) {
            if (first)
                first = false;
            else
                result.append("&");

            result.append(URLEncoder.encode(entry.getKey(), "UTF-8"));
            result.append("=");
            result.append(URLEncoder.encode(entry.getValue(), "UTF-8"));
        }
        return result.toString();
    }
}
