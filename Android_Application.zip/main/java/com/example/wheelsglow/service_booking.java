package com.example.wheelsglow;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

public class service_booking extends AppCompatActivity {
    TextView category_name, service_name, materials, time_taken;
    Button book;
    ImageView images;
    String category_new, service_new;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Intent intent = getIntent();
        category_new = intent.getStringExtra("category");
        service_new = intent.getStringExtra("service");
        setContentView(R.layout.activity_service_booking);
        images = findViewById(R.id.fetch_image);
        book = findViewById(R.id.book_slot);
        category_name = findViewById(R.id.display_category);
        service_name = findViewById(R.id.service_selected);
        category_name.setText(category_new);
        service_name.setText(service_new);
        materials = findViewById(R.id.content_includes);
        time_taken = findViewById(R.id.time_itTakes);

        // Replace "your_php_file_url" with your actual PHP file URL
        String phpUrl = "http://10.0.2.2/wheels/fetch_service_final.php";
        book.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showServiceSelectionDialog();
            }
        });

        new FetchDataTask().execute(phpUrl, category_new, service_new);
    }

    private void showServiceSelectionDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater = this.getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.dialog_service_selection, null);

        builder.setView(dialogView);

        Button homeServiceButton = dialogView.findViewById(R.id.btn_home_service);
        Button showroomServiceButton = dialogView.findViewById(R.id.btn_showroom_service);
        ImageView closeButton = dialogView.findViewById(R.id.btn_close_dialog);

        AlertDialog dialog = builder.create();
        dialog.show();

        closeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });

        homeServiceButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle Home Service button click
                Intent intent=new Intent(service_booking.this,home_service.class);
                startActivity(intent);
                Toast.makeText(service_booking.this, "Home Service selected", Toast.LENGTH_SHORT).show();
                dialog.dismiss();
            }
        });

        showroomServiceButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle Showroom Service button click
                Toast.makeText(service_booking.this, "Showroom Service selected", Toast.LENGTH_SHORT).show();
                dialog.dismiss();
            }
        });
    }

    private class FetchDataTask extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... params) {
            String phpUrl = params[0];
            String category = params[1];
            String service = params[2];

            try {
                URL url = new URL(phpUrl);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setDoOutput(true);

                // Send category and service strings to PHP file
                Map<String, String> postData = new HashMap<>();
                postData.put("category", category);
                postData.put("service", service);
                Log.e("pp", "postdata" + category + service);
                StringBuilder postDataString = new StringBuilder();
                for (Map.Entry<String, String> entry : postData.entrySet()) {
                    if (postDataString.length() != 0) postDataString.append('&');
                    postDataString.append(entry.getKey()).append('=').append(entry.getValue());
                }

                byte[] postDataBytes = postDataString.toString().getBytes("UTF-8");
                conn.getOutputStream().write(postDataBytes);

                BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                StringBuilder response = new StringBuilder();
                String line;
                while ((line = in.readLine()) != null) {
                    response.append(line);
                }
                in.close();
                conn.disconnect();
                return response.toString();
            } catch (IOException e) {
                e.printStackTrace();
                return null;
            }
        }

        @Override


        protected void onPostExecute(String result) {
            Log.e("hio", "result" + result);
            super.onPostExecute(result);
            if (result != null) {
                try {
                    JSONObject jsonObject = new JSONObject(result);
                    JSONArray dataArray = jsonObject.getJSONArray("data");
                    JSONObject dataObject = dataArray.getJSONObject(0);

                    String informations = dataObject.getString("informations");
                    String image = "http://10.0.2.2/wheels/images/" + dataObject.getString("image");
                    String materialsString = dataObject.getString("materials");

                    // Format materialsString with bullet points and remove leading whitespace
                    String[] materialsArray = materialsString.split(", ");
                    StringBuilder formattedMaterials = new StringBuilder();
                    for (String material : materialsArray) {
                        material = material.trim(); // Remove leading and trailing whitespace
                        formattedMaterials.append(material).append("\n");
                    }

                    // Set values to TextViews
                    time_taken.setText(informations);
                    // Assuming you have an image resource with name pcwimg1 in your drawable folder
                    Picasso.get().load(image).into(images);
                    materials.setText(formattedMaterials.toString());
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }


    }
}
