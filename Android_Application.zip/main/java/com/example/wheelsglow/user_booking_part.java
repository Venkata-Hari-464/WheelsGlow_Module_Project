package com.example.wheelsglow;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.razorpay.Checkout;
import com.razorpay.PaymentResultListener;

import org.json.JSONObject;

public class user_booking_part extends AppCompatActivity implements PaymentResultListener {
    String company, model, date, status, amount;
    TextView c, M, D, s;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_booking_part);
        Intent intent = getIntent();
        company = intent.getStringExtra("company");
        model = intent.getStringExtra("carModel");
        date = intent.getStringExtra("date");
        status = intent.getStringExtra("status").trim();
        amount = intent.getStringExtra("amount").trim();
        c = findViewById(R.id.fetch_carCompany);
        M = findViewById(R.id.fetch_carModel);
        D = findViewById(R.id.fetch_bookingDate);
        s = findViewById(R.id.fetch_status);
        c.setText(company);
        M.setText(model);
        D.setText(date);
        s.setText(status);

        // Enable the button if status is "accepted"
        if ("Accepted".equals(status)) {
            Button yourButton = findViewById(R.id.enable_pay);
            yourButton.setVisibility(View.VISIBLE); // Show the button
        } else {
            Button yourButton = findViewById(R.id.enable_pay);
            yourButton.setVisibility(View.GONE); // Hide the button
        }
        Checkout.preload(user_booking_part.this);
    }

    // Handle button click to start the Razorpay checkout process
    public void startBooking(View view) {
        if (amount != null) {
            // Initialize Razorpay checkout
            Checkout checkout = new Checkout();
            checkout.setKeyID("rzp_test_zogp4w4jLlCNCx");

            try {
                // Extract numeric part of amount and convert to paise
                String numericAmount = amount.replaceAll("\\D+", ""); // Extract numeric part (449)
                int amountInPaise = Integer.parseInt(numericAmount) * 100; // Convert to paise
                // Create a JSON object with payment details
                JSONObject options = new JSONObject();
                options.put("name", "wheelsGlow");
                options.put("description", "Enhance car service experiences effortlessly");
                options.put("currency", "INR");
                options.put("amount", amountInPaise);

                JSONObject retryObj = new JSONObject();
                retryObj.put("enable", true);
                retryObj.put("maxcount", 4);
                options.put("retry", retryObj);
                // Open Razorpay checkout activity
                checkout.open(user_booking_part.this, options);
            } catch (Exception e) {
                // Handle exceptions
                Toast.makeText(this, "Error in payment: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                e.printStackTrace();
            }
        } else {
            Toast.makeText(this, "Error: Amount is null", Toast.LENGTH_SHORT).show();
        }
    }

    // Override onPaymentSuccess method to handle payment success
    @Override
    public void onPaymentSuccess(String razorpayPaymentID) {
        // Handle payment success
        Toast.makeText(this, "Payment Successful", Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(user_booking_part.this, customer_home.class);
        startActivity(intent);
    }

    // Override onPaymentError method to handle payment failure
    @Override
    public void onPaymentError(int code, String response) {
        // Handle payment failure
        Toast.makeText(this, "Payment Failed: " + response, Toast.LENGTH_SHORT).show();
        Log.e("Payment", "Payment failed: " + response);
    }
}
