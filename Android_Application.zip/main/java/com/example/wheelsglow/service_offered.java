package com.example.wheelsglow;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

public class service_offered extends AppCompatActivity {
    private RecyclerView recyclerView;
    String category;
    private List<serviceInfo> dataList;
    private CustomAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_service_offered);
        Intent intent = getIntent();
        category = intent.getStringExtra("category");
        recyclerView = findViewById(R.id.service_recyclerView);
        dataList = new ArrayList<>();
        adapter = new CustomAdapter(dataList);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setBackgroundColor(getResources().getColor(android.R.color.white));
        recyclerView.setAdapter(adapter);
        new FetchCategoryDetailsTask().execute(category);
    }

    class CustomAdapter extends RecyclerView.Adapter<CustomAdapter.ViewHolder> {

        private List<serviceInfo> dataList;

        public CustomAdapter(List<serviceInfo> dataList) {
            this.dataList = dataList;
        }

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = getLayoutInflater().inflate(R.layout.custom_cardview, parent, false);
            return new ViewHolder(view);

        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
            serviceInfo service = dataList.get(position);

            holder.nameTextView.setText(service.getService());
            holder.timeTextView.setText(service.getTime());
            holder.amountTextView.setText("Rs."+service.getAmount());
            holder.materialsTextView.setText(service.getMaterials());
            String serviceName = holder.nameTextView.getText().toString();
            holder.moredetails.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(service_offered.this, service_booking.class);
                    intent.putExtra("category",category);
                    intent.putExtra("service",serviceName);
                    startActivity(intent);
                }
            });
        }

        @Override
        public int getItemCount() {
            return dataList.size();
        }

        public class ViewHolder extends RecyclerView.ViewHolder {
            TextView nameTextView, timeTextView, amountTextView, materialsTextView,moredetails;


            public ViewHolder(View itemView) {
                super(itemView);
                nameTextView = itemView.findViewById(R.id.title_service);
                timeTextView = itemView.findViewById(R.id.time_taken);
                amountTextView = itemView.findViewById(R.id.amount_of_service);
                materialsTextView = itemView.findViewById(R.id.service_materials);
                moredetails=itemView.findViewById(R.id.more_details_button);

            }
        }
    }

    private class FetchCategoryDetailsTask extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... params) {
            String category = params[0]; // Get the category passed as parameter
            try {
                URL url = new URL("http://10.0.2.2/wheels/fetch_services.php");
                HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestMethod("POST");
                urlConnection.setDoOutput(true);

                String postData = "category=" + URLEncoder.encode(category, "UTF-8");
                urlConnection.getOutputStream().write(postData.getBytes());

                InputStream inputStream = urlConnection.getInputStream();
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
                StringBuilder response = new StringBuilder();
                String line;
                while ((line = bufferedReader.readLine()) != null) {
                    response.append(line).append("\n");
                }

                bufferedReader.close();
                inputStream.close();
                urlConnection.disconnect();

                return response.toString();
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }

        @Override
        protected void onPostExecute(String result) {
            handleCategoryDetailsResponse(result);
        }
    }

    private void handleCategoryDetailsResponse(String response) {
        if (response != null) {
            try {
                JSONObject jsonResponse = new JSONObject(response);
                String status = jsonResponse.optString("status", "");

                if ("Success".equals(status)) {
                    JSONArray categoryDataArray = jsonResponse.optJSONArray("data");

                    if (categoryDataArray != null) {
                        for (int i = 0; i < categoryDataArray.length(); i++) {
                            JSONObject categoryData = categoryDataArray.optJSONObject(i);

                            if (categoryData == null) {
                                continue;
                            }

                            serviceInfo service = new serviceInfo(
                                    categoryData.optString("service", ""),
                                    categoryData.optString("time", ""),
                                    categoryData.optString("amount", ""),
                                    categoryData.optString("materials", "")
                            );
                            dataList.add(service);
                        }

                        adapter.notifyDataSetChanged();
                    }
                } else if ("NoData".equals(status)) {
                    Log.e("ojo", "No category data available");
                } else {
                    Log.e("ojo", "Error: " + status);
                }
            } catch (JSONException e) {
                e.printStackTrace();
                Log.e("ojo", "JSON parsing error");
            }
        } else {
            Log.e("ojo", "Response is null");
        }
    }

    class serviceInfo {
        private String service;
        private String time;
        private String amount;
        private String materials;

        public serviceInfo(String service, String time, String amount, String materials) {
            this.service = service;
            this.time = time;
            this.amount = amount;
            this.materials = materials;
        }

        public String getService() {
            return service;
        }

        public String getTime() {
            return time;
        }

        public String getAmount() {
            return amount;
        }

        public String getMaterials() {
            return materials;
        }
    }
}
